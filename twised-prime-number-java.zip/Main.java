import java.util.*;  
 public class Main  
{  
    public static void main(String[] args)  
    {  
              
    int n, reverse,sum=0 , temp;  
    Scanner sc = new Scanner(System.in);      
    System.out.println( "prime number");  
    n = sc.nextInt();  
  
        while(n!=0)  
        {  
        reverse = n%10;  
        sum = sum*10 + reverse;  
        n= n/10;  
        }  
        
    temp = 0;  
    for (int j = 2; j <= sum / 2; j++)  
    {  
        if ((sum % j) == 0)  
        {  
            temp = 1;  
            break;  
        }  
    }  
    if (temp == 0)  
            System.out.println("Twisted Prime");  
     else  
            System.out.println("Not Twisted Prime");  
}  
}  